#include <algorithm>
#include <iomanip>
#include <iostream>
#include <set>
#include <vector>

#include "Student.h"

const int kMaxStudents = 5;

int BinarySearch(nwacc::Student list[], int size, nwacc::Student key) {
	auto begin = 0;
	auto end = size - 1;
	auto mid = (begin + end) / 2;

	while (begin <= end) {
		if (list[mid] < key) {
			begin = mid + 1;
		} else if (list[mid] > key) {
			end = mid - 1;
		} else {
			return mid;
		}
		mid = (begin + end) / 2;
	}
	return -1; // not found. 
}

int LinearSearch(nwacc::Student list[], int size, nwacc::Student key) {
	for (auto index = 0; index < size; index++) {
		if (list[index] == key) {
			return index;
		} // else, not the student for which we are looking, doNothing();
	}
	return -1; // not found. 
}

void SelectionSort(nwacc::Student list[], int size) {
	for (int index = 0; index < (size - 1); index++) {
		int minIndex = index;
		nwacc::Student minValue = list[index];

		for (int innerIndex = (index + 1); innerIndex < size; innerIndex++) {
			if (list[innerIndex] < minValue) {
				minIndex = innerIndex;
				minValue = list[innerIndex];
			} // else, not a smaller value doNothing();
		}
		list[minIndex] = list[index];
		list[index] = minValue;
	}
}

int main() {

	// Five types - 
	// Arrays - contiguous memory of the same type AND identifier. Static size
	// Vectors - contigouos memory of the same type AND identifier. Not static size.
	// resizeable array. 
	// Lists - non-contigous memory of the same type and identifier. No random access.
	// Sets - non-contigous memory of the same type and identifier. NO Duplicates!
	// Maps - non-contigous memory of key value pairs with no duplicate keys!
	// dictionary. 

	std::set<std::string> states;
	// how to add items? insert method. The insert method will
	// ignore duplcate values!
	states.insert("FL");
	states.insert("AK");
	states.insert("MN");
	states.insert("CA");
	states.insert("OR");
	states.insert("AR");
	states.insert("MN"); // this will be ignored because it is already in the set. 

	for (auto state : states) {
		std::cout << state << std::endl;
	}

	std::cout << states.size() << std::endl;
	// find returns the iterator to the element if it is found. 
	auto iterator = states.find("TX");
	if (iterator == states.end()) {
		// not found
	} else {
		// found. 
	}


	//
	//std::cout << "Enter a student > ";
	//nwacc::Student student;
	//std::cin >> student;

	//std::cout << student << std::endl;

	//std::vector<nwacc::Student> list;

	//list.push_back(nwacc::Student("Shane", 1));
	//list.push_back(nwacc::Student("Daniel", 2));
	//list.push_back(nwacc::Student("Lela", 6));
	//list.push_back(nwacc::Student("Tamara", 5));
	//list.push_back(nwacc::Student("Janet", 12));
	//std::sort(list.begin(), list.end(), nwacc::Student::sort_by_name);
	//for (auto student : list) {
	//	std::cout << student << std::endl;
	//}
 //
	//bool isFound = std::binary_search(list.begin(), list.end(),
	//	nwacc::Student("Tamara", 1), nwacc::Student::strict_search);

	//std::cout << std::boolalpha << isFound << std::endl;

	//nwacc::Student students[kMaxStudents];

	//students[0] = nwacc::Student("Shane", 1);
	//nwacc::Student student("Daniel", 2);
	//students[1] = student;
	//students[2] = nwacc::Student("Lela", 6);
	//students[3] = nwacc::Student("Tamara", 5);
	//students[4] = nwacc::Student("Janet", 12);

	//bool isFound = std::binary_search(students, students + kMaxStudents,
	//nwacc::Student("Tamara", 1));

	//std::cout << std::boolalpha << isFound << std::endl;

	//bool isLessThan = 
	//	nwacc::Student::sort_by_name(students[0], students[1]);
	//std::cout << std::boolalpha << isLessThan << std::endl;

	//std::sort(students, students + kMaxStudents);
	//for (auto student : students) {
	//	std::cout << student << std::endl;
	//}

	//std::sort(students, students + kMaxStudents,
	//	nwacc::Student::sort_by_name);
	//for (auto student : students) {
	//	std::cout << student << std::endl;
	//}

	return 0;
}