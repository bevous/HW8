#ifndef STUDENT_H_
#define STUDENT_H_

#include <string>

namespace nwacc {
	class Student {
	private:
		std::string name;
		int id;
		int compare_to(const Student&) const;
		bool equals(const Student&) const;
	public:
		static const int kFirstId = 1;
		Student();
		Student(std::string, int);
		std::string get_name() const;
		void set_name(const std::string&);
		int get_id() const;
		void set_id(int);

		static bool sort_by_name(const Student&, const Student&);
		static bool strict_search(const Student&, const Student&);

		bool operator< (const Student&) const;
		bool operator> (const Student&) const;
		bool operator<= (const Student&) const;
		bool operator>= (const Student&) const;
		bool operator== (const Student&) const;
		bool operator!= (const Student&) const;

		friend std::ostream& operator<< (std::ostream&, const Student&);
		friend std::istream& operator>> (std::istream&, Student&);

	};
}

#endif // !STUDENT_H_
